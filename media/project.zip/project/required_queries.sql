/* Single table queries */

/* The marketing team wants to know how much the markup is (in percents) of the
suggested price they give to the customer compared to the cost price. They want
this information because they want to make sure the current markup percents
matches current and future trends. If the markup doesnt match,
then the suggested price will be changed to match the trends. */
SELECT product_id, (((suggested_price / (price / unit_of_sale))-1)*100) AS PERCENT_MARKUP
FROM product;

/* Jerimiah Remington is a Sales Associate and wants a list of all of their customers that are in bad
credit standing so that they can call each customer and go over with them the
 proper procedures to handle the bad credit rating before the next time they order
 something. */
 SELECT customer_id, customer_name, credit_standing, phone
 FROM customers
 WHERE credit_standing < 640 and employee_id = 'E000007654';

/* It is the last day of the month and the HR manager wants a list of all the employees who were hired in the month
 following the current month in the past. This is so they can schedule the employees
  annual evaluation. */
SELECT employee_id, start_date
FROM employees
WHERE EXTRACT(MONTH FROM start_date) = EXTRACT(MONTH FROM DATE_ADD(CURDATE(), INTERVAL 1 MONTH));

/* A customer wants to know how many images are associated with the JumpHigh Supreme Basketballs
 so that they can strategize and organize proper floor displays for the product */
 SELECT COUNT(product_id) AS NUMBER_OF_IMAGES
 FROM product_images
 WHERE product_id = 'PROD000123';

 /* A member of Product Acquisitions wants a list of all the products whose stock
 is below the reorder point so that they can order more to stock. With each product
  listed, they also want to know how much of each product they should order*/
SELECT product_id, (max_stock - stock) AS HOW_MUCH_TO_ORDER
FROM product
WHERE stock < reorder_point;

/*Multi-table Queries*/

/* Big John's Sports Emporium just placed an order. The order entry people need to
 know which warehouse to send the order to in order to be fullfilled. */
SELECT warehouse_id
FROM customers c, regions r, warehouses w
WHERE c.region_id = r.region_id AND r.region_id = w.region_id AND customer_id = 'C235673450';

/* Miao X Wants to know how much their most recent order was so that they can
put it in their system.*/
SELECT o.order_id, MAX(date_ordered) AS LAST_ORDER_DATE, (ol.num_ordered * p.price) AS ORDER_TOTAL
FROM orders o, order_line ol, product p
WHERE o.order_id = ol.order_id AND ol.product_id = p.product_id AND customer_id = 'C223488887';

/* An Order Fullfillment Employee wants a list of all the orders that are on hold, and
Product that they are on hold for so that they can inquire about ordering more of the product
 to eventually fullfill the order */
SELECT o.order_id, ol.product_id, num_ordered, p.stock
FROM orders o, order_line ol, product p
WHERE o.order_id = ol.order_id AND ol.product_id = p.product_id AND p.stock < ol.num_ordered;
