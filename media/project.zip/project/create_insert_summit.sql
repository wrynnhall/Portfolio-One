/* Create Summit database */
CREATE DATABASE summit;

/* Create the Regions table */
CREATE TABLE regions(
	region_id varchar(10) PRIMARY KEY,
	region_name varchar(15)
);

/* Create the Warehouses table*/
CREATE TABLE warehouses(
	warehouse_id char(5) PRIMARY KEY,
	region_id varchar(10),
	street varchar(100),
	city varchar(30),
	state char(2),
	zip_code varchar(10),
	country varchar(30),
	phone varchar(16),
	FOREIGN KEY(region_id) REFERENCES regions(region_id)
);

/* Create the Departments table */
CREATE TABLE departments(
	department_id char(5) PRIMARY KEY,
	department_name varchar(50)
);

/* Create the Employees table */
CREATE TABLE employees(
	employee_id char(10) PRIMARY KEY,
	last_name varchar(30),
	first_name varchar(30),
	start_date date,
	title varchar(15),
	salary decimal(12,2),
	commission_rate decimal(5,4),
	comments varchar(1000),
	department_id char(5),
	FOREIGN KEY(department_id) REFERENCES departments(department_id)
);

/* Create the Customers table */
CREATE TABLE customers(
	customer_id char(10) PRIMARY KEY,
	customer_name varchar(30),
	street varchar(100),
	city varchar(30),
	state char(2),
	zip_code varchar(10),
	country varchar(30),
	phone varchar(13),
	credit_standing int,
	region_id varchar(10),
	comments varchar(1000),
	employee_id char(10),
	FOREIGN KEY(region_id) REFERENCES regions(region_id),
	FOREIGN KEY(employee_id) REFERENCES employees(employee_id)
);

/* Create the Product table */
CREATE TABLE product(
	product_id char(10) PRIMARY KEY,
	product_name varchar(30),
	product_description varchar(1000),
	price decimal(9,2),
	stock int,
	max_stock int,
	restock_date date,
	reason_out_of_stock varchar(50),
	reorder_point int,
	suggested_price decimal(9,2),
	unit_of_sale int
);

/* Create the Product_Images table */
CREATE TABLE product_images(
	product_id char(10),
	image_id char(10),
	image_path varchar(50),
	image_description varchar(500),
	PRIMARY KEY(product_id, image_id),
	FOREIGN KEY(product_id) REFERENCES product(product_id)
);

/* Create the Orders table */
CREATE TABLE orders(
	order_id char(10) PRIMARY KEY,
	date_ordered date,
	date_shipped date,
	payment_type varchar(10),
	customer_id char(10),
	is_on_hold char(1),
	FOREIGN KEY(customer_id) REFERENCES customers(customer_id)
);

/* Create the Order_Line table*/
CREATE TABLE order_line(
	order_id char(10),
	product_id char(10),
	num_ordered int,
	PRIMARY KEY(order_id, product_id),
	FOREIGN KEY(order_id) REFERENCES orders(order_id),
	FOREIGN KEY(product_id) REFERENCES product(product_id)
);

/* Insert values into Regions table*/
INSERT INTO regions VALUES('NA1', 'North America 1');
INSERT INTO regions VALUES('SA1', 'South America 1');
INSERT INTO regions VALUES('AME1', 'Africa/Middle East 1');
INSERT INTO regions VALUES('AS1', 'Asia 1');
INSERT INTO regions VALUES('EU1', 'Europe 1');

/* Insert values into Warehouses table*/
INSERT INTO warehouses VALUES(
	'WH001', 'NA1', '4803 Ferncliff Dr', 'Chicago', 'IL', '34564', 'USA', '(800)-800-2934'
);
INSERT INTO warehouses VALUES(
	'WH002', 'SA1', '1312 Sunset Blvd', 'Buenos Aires', NULL, NULL, 'Argentina', '(800)-777-1287'
);
INSERT INTO warehouses VALUES(
	'WH003', 'AS1', 'No. 1952, 1125, Chang Jiang Dong Lu Guang Ming Xing Zheng Cun, Juchao District',
	'Chaohu City', NULL, NULL, 'China', '(300)-235-8764'
);
INSERT INTO warehouses VALUES(
	'WH004', 'EU1', '1818 West Side Avenue', 'Healey', NULL, 'CV5 2NP', 'United Kingdom', '(111)-238-5479'
);
INSERT INTO warehouses VALUES(
	'WH005', 'AME1', 'Gridco Bldg - 3, C Ring Rd', 'Doha', NULL, NULL, 'Quatar', '(444)-326-78'
);

/* Insert values into Departments table*/
INSERT INTO departments VALUES('DP000', 'Marketing');
INSERT INTO departments VALUES('DP100', 'Billing');
INSERT INTO departments VALUES('DP200', 'Accounting');
INSERT INTO departments VALUES('DP300', 'Accounts Receivable');
INSERT INTO departments VALUES('DP400', 'Order Entry');
INSERT INTO departments VALUES('DP500', 'Sales');

/* Insert values into Employees table*/
INSERT INTO employees VALUES(
	'E000002345', 'Anderson', 'Jessica', '2012-05-29', 'Hiring Manager', 93467.77,
	 NULL, 'Bachelors Business Management, Harvard', 'DP000'
);
INSERT INTO employees VALUES(
	'E000006895', 'Blake', 'Richard', '2012-08-15', 'Entry-Level Sales Person', 40355.55,
	 0.15, 'Bachelors Sales Marketing, Iowa State', 'DP500'
);
INSERT INTO employees VALUES(
	'E000007654', 'Remington', 'Jerimiah', '2013-01-10', 'Secont-Tier Sales Person', 50100.25,
	 0.2, 'Bachelors Sales Marketing, University of Oklahoma', 'DP500'
);
INSERT INTO employees VALUES(
	'E000009543', 'Erp', 'Katrina', '2013-06-12', 'Marketing Manager', 200567.57,
	 NULL, 'Master Sales Marketing, University of Utah', 'DP000'
);
INSERT INTO employees VALUES(
	'E000009579', 'Jones', 'Patricia', '2013-06-13', 'Billing Associate', 32560.45,
	 NULL, 'Associate Business, Riverland Community College', 'DP100'
);

/* Insert values into Product table*/
INSERT INTO product VALUES(
	'PROD000123', 'JumpHigh Supreme Basketballs', 'The number one basketball in the country',
	1000.50, 19, 50, '2017-04-01', NULL, 20, 15.79, 100
);
INSERT INTO product VALUES(
	'PROD006743', 'Bobcat Premium Easy-Lace Soccer Cleets', 'Be the fastest runner on the pitch',
	650.50, 375, 500, '2017-03-01', NULL, 100, 45.99, 20
);
INSERT INTO product VALUES(
	'PROD025798', 'Hooser Ultimate Goalie Stick', 'Stop any puck coming your way',
	200.65, 10, 40, '2017-03-01', NULL, 15, 8.80, 50
);
INSERT INTO product VALUES(
	'PROD025945', 'Baddidas Neon Yellow Rain Coat', 'Whicks away every single moisture',
	400.34, 300, 350, '2017-04-15', NULL, NULL, 45.79, 12
);
INSERT INTO product VALUES(
	'PROD025999', 'Over Armour Black Leggings', 'Stay cool while staying kewl',
	300, 0, 50, '2017-02-10', 'Producer has ceased production', NULL, 10.99, 35
);

/* Insert values into Product_Images table*/
INSERT INTO product_images VALUES(
	'PROD000123', 'IMG0004321', '3er456td21w_prodpic.png', 'Shows a little kid playing with the basketball'
);
INSERT INTO product_images VALUES(
	'PROD000123', 'IMG0004322', '3er456td22w_prodpic.png', 'A picture of just the basketball'
);
INSERT INTO product_images VALUES(
	'PROD006743', 'IMG0004401', '5rt7yv87w121_prodpic.png', 'A picture of Lionel Messi kicking a ball with the product on his feet'
);
INSERT INTO product_images VALUES(
	'PROD025798', 'IMG0004567', '3er456tdd21w_prodpic.png', 'A street hocket game with a goalie blocking a puck with the product stick'
);
INSERT INTO product_images VALUES(
	'PROD025945', 'IMG0004680', '4jh2g4hjkl45_prodpic.png', 'A man running with the product on in the rain'
);

/* Insert values into Customers table*/
INSERT INTO customers VALUES(
	'C235673450', 'Big John''s Sports Emporium', '123 1st St', 'San Francisco',
	'CA', '90216', 'USA', '(555) 345-5679', 744, 'NA1', NULL, 'E000006895'
);
INSERT INTO customers VALUES(
	'C235768900', 'Womansports', '456 2nd Ave', 'Seattle',
	'WA', '56478', 'USA', '(555) 324-7801', 680, 'NA1', NULL, 'E000006895'
);
INSERT INTO customers VALUES(
	'C223488887', 'Miao X', 'No. 953, 1280, Mei Han Zhen You Zhuang, Wuqing District',
	'Tianjin City', NULL, NULL, 'China', '(222) 567-9235', 645, 'AS1', NULL, 'E000007654'
);
INSERT INTO customers VALUES(
	'C223348732', 'Cardoso Equipment Store', 'Rua Manuelito Pereira 382',
	'Mossoró', NULL, NULL, 'Brazil', '(900) 123-8172', 520, 'SA1', NULL, 'E000007654'
);
INSERT INTO customers VALUES(
	'C223343334', 'Smith Sports', '70 Colorado Way',
	'Ribchester', NULL, NULL, 'UK', '(800) 176-1283', 655, 'EU1', NULL, 'E000007654'
);

/* Insert values into Orders table*/
INSERT INTO orders VALUES(
	'I0001236587', '2017-03-29', '2017-03-30', 'checking', 'C235673450', 'Y'
);
INSERT INTO orders VALUES(
	'I0001232375', '2017-03-30', '2017-04-01', 'checking', 'C235768900', 'N'
);
INSERT INTO orders VALUES(
	'I0001232399', '2017-04-05', '2017-04-06', 'checking', 'C223488887', 'N'
);
INSERT INTO orders VALUES(
	'I0001232456', '2017-04-05', '2017-04-07', 'checking', 'C223348732', 'N'
);
INSERT INTO orders VALUES(
	'I0001232467', '2017-04-10', '2017-04-11', 'checking', 'C223343334', 'N'
);

/* Insert values into Order_Line table*/
INSERT INTO order_line VALUES(
	'I0001236587', 'PROD000123', 1
);
INSERT INTO order_line VALUES(
	'I0001236587', 'PROD025999', 2
);
INSERT INTO order_line VALUES(
	'I0001232467', 'PROD025945', 5
);
INSERT INTO order_line VALUES(
	'I0001232456', 'PROD025798', 2
);
INSERT INTO order_line VALUES(
	'I0001232399', 'PROD025945', 4
);
